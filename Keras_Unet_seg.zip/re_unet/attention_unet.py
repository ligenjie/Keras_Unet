# -*-coding:utf-8-*-
"""
@Time:      2020-05-28  16:24
@Author:    Genjie
@IDE:       PyCharm
"""

from keras.layers import PReLU,Conv2D,Input,MaxPool2D,Lambda,MaxPooling2D
from keras.layers import add,concatenate,Add,UpSampling2D,Activation,Multiply
from keras.models import  Model
from keras_contrib.layers import GroupNormalization
import keras.backend as K
from keras.regularizers import l2

def _gn_relu(input):
    num_groups = K.int_shape(input)[-1]//8
    if num_groups==0:
        num_groups = K.int_shape(input)[-1]
    norm = GroupNormalization(groups=num_groups)(input)
    return Activation('relu')(norm)

def _gn_sigmoid(input):
    num_groups = K.int_shape(input)[-1]//8
    if num_groups==0:
        num_groups = K.int_shape(input)[-1]
    norm = GroupNormalization(groups=num_groups)(input)
    return Activation('sigmoid')(norm)

def _conv_gn(**conv_params):
    filters = conv_params['filters']
    kernel_size = conv_params['kernel_size']
    strides = conv_params.setdefault('strides',(1,1))
    kernel_initializer = conv_params.setdefault('kernel_initializer','he_normal')
    padding = conv_params.setdefault('padding','same')
    kernel_regularizer = conv_params.setdefault('kernel_regularizer',l2(1.e-6))

    def f(input):
        x = Conv2D(filters=filters,kernel_size=kernel_size,strides=strides,padding=padding,
                   kernel_initializer=kernel_initializer,
                   kernel_regularizer=kernel_regularizer,use_bias=False)(input)
        num_groups = filters//8
        if num_groups==0:
            num_groups = filters
        x = GroupNormalization(groups=num_groups)(x)
        return x
    return f

def _conv_gn_relu(**conv_params):
    filters = conv_params['filters']
    kernel_size = conv_params['kernel_size']
    strides = conv_params.setdefault('strides',(1,1))
    kernel_initializer = conv_params.setdefault('kernel_initializer','he_normal')
    padding = conv_params.setdefault('padding','same')
    kernel_regularizer = conv_params.setdefault('kernel_regularizer',l2(1.e-6))

    def f(input):
        conv = Conv2D(filters=filters,kernel_size=kernel_size,strides=strides,padding=padding,
                   kernel_initializer=kernel_initializer,
                   kernel_regularizer=kernel_regularizer,use_bias=False)(input)
        return _gn_relu(conv)

    return f

def _conv_gn_sigmoid(**conv_params):
    filters = conv_params['filters']
    kernel_size = conv_params['kernel_size']
    strides = conv_params.setdefault('strides',(1,1))
    kernel_initializer = conv_params.setdefault('kernel_initializer','he_normal')
    padding = conv_params.setdefault('padding','same')
    kernel_regularizer = conv_params.setdefault('kernel_regularizer',l2(1.e-6))

    def f(input):
        conv = Conv2D(filters=filters,kernel_size=kernel_size,strides=strides,padding=padding,
                      kernel_initializer=kernel_initializer,
                      kernel_regularizer=kernel_regularizer,use_bias=False)(input)
        return _gn_sigmoid(conv)

    return f

def conv_block(**conv_params):
    filters = conv_params['filters']

    def f(input):
        x = _conv_gn_relu(filters=filters,kernel_size=3)(input)
        x = _conv_gn_relu(filters=filters,kernel_size=3)(x)
        return x
    return f

def up_conv(**conv_params):
    filters = conv_params['filters']

    def f(input):
        x = UpSampling2D(size=(2,2))(input)
        x = _conv_gn_relu(filters=filters,kernel_size=3)(x)
        return x
    return f

def  down_conv(**conv_params):
    filters = conv_params['filters']
    strides = conv_params.setdefault('strides',(2,2))

    def f(input):
        x = _conv_gn_relu(filters=filters,kernel_size=3,strides=strides)(input)
        return x

    return f

def attention_block(**conv_params):
    f_int = conv_params['f_int']

    def f(g,x):
        w_g = _conv_gn(filters=f_int,kernel_size=1)(g)
        w_x = _conv_gn(filters=f_int,kernel_size=1)(x)
        psi = Activation('relu')(Add())([w_g,w_x])
        psi = _conv_gn_sigmoid(filters=1,kernel_size=1)(psi)
        channels = K.int_shape(x)[-1]
        psi = Lambda(lambda x,rep:K.repeat_elements(x,rep,axis=-1),
                     arguments={'rep':channels})(psi)
        return Multiply()[x,psi]

    return f

def attention_unet(input_size = (1024,1204,3),num_classes = 3):
    inputs = Input(shape=input_size,name='inputs')

    x1 = conv_block(filters = 64)(inputs)

    x2 = MaxPooling2D(pool_size=[2,2])(x1)
    x2 = conv_block(filters=128)(x2)

    x3 = MaxPooling2D(pool_size=[2,2])(x2)
    x3 = conv_block(filters=256)(x3)

    x4 = MaxPooling2D(pool_size=[2,2])(x3)
    x4 = conv_block(filters=512)(x4)

    x5 = MaxPooling2D(pool_size=[2,2])(x4)
    x5 = conv_block(filters=1024)(x5)

    #上采样
    d5 = up_conv(filters=512,kernel_size=3)(x5)
    x4 = attention_block(f_int=256)(d5,x4)
    d5 = concatenate([x4,d5],axis=-1)
    d5 = conv_block(filters=512)(d5)

    d4 = up_conv(filters=256)(d5)
    x3 = attention_block(f_int=128)(d4,x3)
    d4 = concatenate([x3,d4],axis=-1)
    d4 = conv_block(filters=256)(d4)

    d3 = up_conv(filters=256)(d4)
    x2 = attention_block(f_int=128)(d3,x2)
    d3 = concatenate([x2,d3],axis=-1)
    d3 = conv_block(filters=128)(d3)

    d2 = up_conv(filters=256)(d3)
    x1 = attention_block(f_int=128)(d2,x1)
    d2 = concatenate([x1,d2],axis=-1)
    d2 = conv_block(filters=64)(d2)
    out_seg = Conv2D(num_classes,1,padding='same',name='out_seg',use_bias=True,activation='sigmoid')(d2)

    model = Model(inputs=[inputs],outputs=[out_seg],name='attention_unet')
    return model

def unet(input_size = (1024,1024,3),num_class=4):
    inputs = Input(shape=input_size,name='inputs')

    x1 = conv_block(filters=64)(inputs)

    x2 = down_conv(filters=64)(x1)
    x2 = conv_block(filters=128)(x2)

    x3 = down_conv(filters=128)(x2)
    x3 = conv_block(filters=256)(x3)

    x4 = down_conv(filters=256)(x3)
    x4 = conv_block(filters=512)(x4)

    x5 = down_conv(filters=512)(x4)
    x5 = conv_block(filters=1024)(x5)

    d5 = up_conv(filters=512)(x5)
    d5 = concatenate([x4,d5],axis=-1)
    d5 = conv_block(filters=512)(d5)

    d4 = up_conv(filters=256)(d5)
    d4 = concatenate([x3,d4],axis=-1)
    d4 = conv_block(filters=256)(d4)

    d3 = up_conv(filters=128)(d4)
    d3 = concatenate([x2,d3],axis=-1)
    d3 = conv_block(filters=128)(d3)

    d2 = up_conv(filters=64)(d3)
    d2 = concatenate([x1,d2],axis=-1)
    d2 = conv_block(filters=64)(d2)

    out_seg = Conv2D(num_class,1,padding='same',name='out_seg',use_bias=True,activation='sigmoid')(d2)

    model = Model(inputs=[inputs],outputs=[out_seg],name='unet')
    return model

def unet_fpn(input_size=(1024,1024,3),num_class=4):
    inputs = Input(shape=input_size,name='Inputs')
    x1 = conv_block(filters=64)(inputs)

    x2 = down_conv(filters=64)(x1)
    x2 = conv_block(filters=128)(x2)

    x3 = down_conv(filters=128)(x2)
    x3 = conv_block(filters=256)(x3)

    x4 = down_conv(filters=256)(x3)
    x4 = conv_block(filters=512)(x4)

    x5 = down_conv(filters=512)(x4)
    x5 = conv_block(filters=1024)(x5)

    d5 = up_conv(filters=512)(x5)
    d5 = concatenate([x4,d5],axis=-1)
    d5 = conv_block(filters=512)(d5)

    d4 = up_conv(filters=256)(d5)
    d4 = concatenate([x3,d4],axis=-1)
    d4 = conv_block(filters=256)(d4)

    d3 = up_conv(filters=128)(d4)
    d3 = concatenate([x2,d3],axis=-1)
    d3 = conv_block(filters=128)(d3)

    d2 = up_conv(filters=64)(d3)
    d3 = concatenate([x1,d2],axis=-1)
    d3 = conv_block(filters=64)(d3)

    p5 = Conv2D(128,(1,1),name='fpn_c5p5')(d5)

    p4 = Add(name='fpn_p4add')([UpSampling2D(size=(2,2),name='fpn_p4upsampled')(p5)
                               ,Conv2D(128,1,name='fpn_c4p4')(d4)])#channel = 128

    p3 = Add(name='fpn_p3add')([UpSampling2D(size=(2,2),name='fpn_p3upsampled')(p4)
                               ,Conv2D(128,1,name='fpn_c3p3')(d3)])#channel = 128

    p2 = Add(name='fpn_p2add')([UpSampling2D(size=(2,2),name='fpn_p2upsampled')(p3)
                                ,Conv2D(128,1,name='fpn_c2p2')(d2)])

    #用卷积来平滑
    p2 = Conv2D(128,(3,3),padding='same',name='smooth_p2')(p2)

    out_seg = Conv2D(num_class,1,padding='same',name='out_seg',use_bias=True,activation='sigmoid')(p2)
    #建立模型
    model = Model(inputs = [inputs],outputs=[out_seg],name='attention_unet_fpn')
    return model




def _res_gn_relu(x,filters):
    x1 = Conv2D(filters,3,padding='same',use_bias=False)(x)
    num_groups = K.int_shape(x1)[-1]//8
    x1 = GroupNormalization(groups=num_groups)(x1)
    x1 = PReLU()(x1)


    x1 = Conv2D(filters,3,padding='same',use_bias=False)(x1)
    num_groups = K.int_shape(x1)[-1]//8
    x1 = GroupNormalization(groups=num_groups)(x1)
    x1 = PReLU()(x1)

    x1 = add([x,x1])

    return x1

def conv_res_block(**conv_params):
    filters = conv_params['filters']

    def f(input):
        x = _res_gn_relu(input,filters=filters)
        x = _res_gn_relu(x,filters=filters)
        return x
    return f


def conv_res_block_decode(**conv_params):
    filters = conv_params['filters']

    def f(input):
        x = _res_gn_relu(input,filters=filters)
        return x

    return f


def unet_res(input_size=(1024,1024,3),num_class = 4):
    inputs = Input(shape=input_size,name='inputs')

    x0 = Conv2D(32,3,padding='same',use_bias=False)(inputs)
    x1 = conv_res_block(filters=32)(x0)

    x2 = down_conv(filters=64)(x1)
    x2 = conv_res_block(filters=64)(x2)

    x3 = down_conv(filters=128)(x2)
    x3 = conv_res_block(filters=128)(x3)

    x4 = down_conv(filters=256)(x3)
    x4 = conv_res_block(filters=256)(x4)

    x5 = down_conv(filters=512)(x4)
    x5 = conv_res_block(filters=512)(x5)

    d5 = up_conv(filters=256)(x5)
    d5 = concatenate([x4,d5],axis=-1)
    d5 = conv_res_block_decode(filters=512)(d5)

    d4 = up_conv(filters=128)(d5)
    d4 = concatenate([x3,d4],axis=-1)
    d4 = conv_res_block_decode(filters=256)(d4)

    d3 = up_conv(filters=64)(d4)
    d3 = concatenate([x2,d3],axis=-1)
    d3 = conv_res_block_decode(filters=128)(d3)

    d2 = up_conv(filters=32)(d3)
    d2 = concatenate([x1,d2],axis=-1)
    d2 = conv_res_block_decode(filters=64)(d2)

    out_seg = Conv2D(num_class,1,padding='same',name='out_seg',use_bias=True,activation='sigmoid')(d2)

    model = Model(inputs=[inputs],outputs=[out_seg],name='attention_unet')
    return model




