# -*-coding:utf-8-*-
"""
@Time:      2020-05-28  16:24
@Author:    Genjie
@IDE:       PyCharm
"""

from keras.losses import binary_crossentropy,categorical_crossentropy
import keras.backend as K
import tensorflow as tf
from keras.backend.tensorflow_backend import _to_tensor
import numpy as np
import cv2

def loss(y_true,y_pred):
    pass


def dice_coeff(y_true,y_pred):
    smooth = 1.
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_pred_f*y_pred_f)
    score = (2.*intersection+smooth)/(K.sum(y_true_f)+K.sum(y_pred_f)+smooth)
    return score

def multi_dice_coeff(y_true,y_pred):
    nums_classes = K.int_shape(y_pred)[-1]
    dice_sum = 0.
    for classid in range(0,nums_classes):
        dice_sum += dice_coeff(y_true[...,classid],y_pred[...,classid])
    return dice_sum/nums_classes


def dice_loss(y_true,y_pred):
    loss = 1-dice_coeff(y_true,y_pred)
    return loss

def bce_dice_loss(y_true,y_pred,dice=0.5,bce=0.5):
    loss = binary_crossentropy(y_true,y_pred)*bce+dice_loss(y_true,y_pred)*dice
    return loss

def iou_loss(y_true,y_pred):
    smooth = 1.
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f*y_pred_f)
    iou = (intersection+smooth)/(K.sum((y_pred_f)+K.sum(y_true_f)-intersection+smooth))
    return 1-iou

def iou(y_true,y_pred):
    smooth = 1.
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f*y_pred_f)
    iou = (intersection+smooth)/(K.sum((y_pred_f)+K.sum(y_true_f)-intersection+smooth))
    return iou

#------------Jaccard_losss----------#
def Jaccard_loss(y_true,y_pred):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f*y_pred_f)
    loss = binary_crossentropy(y_true,y_pred)+1-intersection/(K.sum(y_true_f)+K.sum(y_pred_f)-intersection)
    return loss


def Jaccard_metric(y_true,y_pred):
    smooth = 1.
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f*y_pred_f)
    return (2.*intersection+smooth)/(K.sum(y_true_f*y_pred_f)+K.sum(y_pred_f*y_pred_f)+smooth)
