# -*-coding:utf-8-*-
"""
@Time:      2020-05-28  16:38
@Author:    Genjie
@IDE:       PyCharm
"""
import numpy as np
def gamma_correction(image,gamma):
    assert image.ndim==3 or image.ndim==1
    if image.ndim==3:
        new_img = np.ones(image.shape,dtype=np.float)
        B = image[:,:,0]
        G = image[:,:,1]
        R = image[:,:,2]
        B_gamma = np.power(B/255.,gamma)
        G_gamma = np.power(G/255.,gamma)
        R_gamma = np.power(R/255.,gamma)
        new_img[:,:,0] = B_gamma
        new_img[:,:,1] = G_gamma
        new_img[:,:,2] = R_gamma
    else:
        new_img = np.power(image/float(np.max(image)),gamma)

    return (new_img*255).astype('uint8')