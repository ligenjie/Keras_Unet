# -*-coding:utf-8-*-
"""
@Time:      2020-05-28  16:33
@Author:    Genjie
@IDE:       PyCharm
"""
import warnings
warnings.filterwarnings('ignore')

import attention_unet as att_unet
from keras.callbacks import ReduceLROnPlateau,ModelCheckpoint,TensorBoard
import os
import cv2
import numpy as np
import tensorflow as tf
import keras.backend as K
import datetime
from myutils import gamma_correction
import keras.optimizers as optim
from keras.callbacks import LearningRateScheduler
from losses import  Jaccard_loss,iou
import matplotlib.pyplot as plt
import data_augumentation as aug
print(tf.__version__)
#选定GPU
#os.environ['CUDA_VISIBLE_DEVICES']='0'
#设置tf.session的属性比如能使用多少gpu，线程等等
config = tf.compat.v1.ConfigProto()
sess = tf.compat.v1.Session(config=config)
K.tensorflow_backend.set_session(sess)


#————————————————————————Config---------------------
input_size = 512
epochs = 200
lr_base = 1e-3
decay = 10
lr_power = 0.9
batch_size = 1
num_class = 1
num_gpu = 1
finetuning = False

#select model
model = 'attention.unet'
label_thresholds = 255

data_dir = r'./data'
now = datetime.datetime.now()

save_dir = r'./save_model'
pretrained_model_path = r'input'


if not os.path.exists(save_dir):
    os.mkdir(save_dir)
model_name = model+'{epoch:04d}-{val_iou:.2f}.hdf5'
model_path = os.path.join(save_dir,model_name)


if model=='attention.unet':
    model = att_unet.unet(input_size=(input_size,input_size,3),num_class=num_class)

if finetuning:
    model.load_weights(pretrained_model_path)

optimizer = optim.adam(lr=1e-2)
model.compile(optimizer=optimizer,loss=Jaccard_loss,metrics=[iou])

# model.summary()
train_imgae_dir = os.path.join(data_dir,'images_train')
val_imgae_dir = os.path.join(data_dir,'images_val')
train_mask_dir = os.path.join(data_dir,'masks_train')
val_mask_dir = os.path.join(data_dir,'masks_val')


ids_train_split = []
for file in os.listdir(train_imgae_dir):
    if file.endswith('.png'):
        ids_train_split.append(file)

ids_valid_split = []
for file in os.listdir(val_imgae_dir):
    if file.endswith('.png'):
        ids_valid_split.append(file)


print('Training on {} samples'.format(len(ids_train_split)))
print('Validating on {} samples'.format(len(ids_valid_split)))

def train_generator():
    while True:
        np.random.shuffle(ids_train_split)
        for start in range(0,len(ids_train_split),batch_size):
            x_batch = []
            y_batch = []
            end = min(start+batch_size,len(ids_train_split))
            ids_train_batch = ids_train_split[start:end]
            np.random.shuffle(ids_train_batch)
            for image_id in ids_train_batch:
                img = cv2.imread(os.path.join(train_imgae_dir,image_id))
                img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
                #gamma变换
                img = gamma_correction(img,1/1.8)
                if os.path.exists(os.path.join(train_mask_dir,image_id)):
                    mask = cv2.imread(os.path.join(train_mask_dir,image_id),cv2.IMREAD_GRAYSCALE)
                else:
                    raise Exception(image_id+' label file not existed!')

                all_masks = []

                new_mask = np.zeros(mask.shape)
                new_mask[mask>label_thresholds] = 1
                all_masks.append(new_mask)

                # print(img)
                # print(all_masks)

                img,all_masks = aug.randomElasticTransformation(img,all_masks)
                img,all_masks = aug.randomShiftScaleRotate(img,all_masks,shift_limit=(-0.0625,0.0625)
                                                           ,scale_limit=(-0.1,0.1)
                                                           ,rotate_limit=(-180,180))
                img,all_masks = aug.randomHorizontalFlip(img,all_masks)
                all_masks = np.stack(np.array(all_masks),axis=-1)
                x_batch.append((img-np.mean(img)/np.std(img)))
                y_batch.append(all_masks)
            x_batch = np.array(x_batch,np.float32)
            y_batch = np.array(y_batch,np.int8)

            yield x_batch,y_batch

def valid_generator():
    while True:
        np.random.shuffle(ids_valid_split)
        for start in range(0,len(ids_valid_split),batch_size):
            x_batch = []
            y_batch = []
            end = min(start+batch_size,len(ids_valid_split))
            ids_valid_batch = ids_valid_split[start:end]
            np.random.shuffle(ids_valid_batch)
            for image_id in ids_valid_batch:
                img = cv2.imread(os.path.join(val_imgae_dir,image_id))
                img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
                #gamma变换
                img = gamma_correction(img,1/1.8)
                if os.path.exists(os.path.join(val_mask_dir,image_id)):
                    mask = cv2.imread(os.path.join(val_mask_dir,image_id),cv2.IMREAD_GRAYSCALE)
                else:
                    raise Exception(image_id+' label file not existed!')

                all_masks = []
                for idx in range(len(label_thresholds)):
                    new_mask = np.zeros(mask.shape)
                    new_mask[mask==label_thresholds[idx]] = 1
                    all_masks.append(new_mask)

                img,all_masks = aug.randomElasticTransformation(img,all_masks)
                img,all_masks = aug.randomShiftScaleRotate(img,all_masks,shift_limit=(-0.0625,0.0625)
                                                           ,scale_limit=(-0.1,0.1)
                                                           ,rotate_limit=(-180,180))
                img,all_masks = aug.randomHorizontalFlip(img,all_masks)
                all_masks = np.stack(np.array(all_masks),axis=-1)
                x_batch.append((img-np.mean(img)/np.std(img)))
                y_batch.append(all_masks)
            x_batch = np.array(x_batch,np.float32)
            y_batch = np.array(y_batch,np.int8)

            yield x_batch,y_batch


def lr_scheduler(epoch):
    lr = lr_base*((1-float(epoch)/epochs**lr_power))
    return lr

if __name__ == '__main__':
    scheduler = LearningRateScheduler(lr_scheduler)
    callbacks = [
        scheduler,
        ModelCheckpoint(
            monitor='val_iou',
            filepath=model_path,save_best_only=True,
            save_weights_only=True,mode='max'),TensorBoard(log_dir=save_dir)
    ]

    h = model.fit_generator(generator=train_generator(),
                            steps_per_epoch=len(ids_train_split)//batch_size,epochs=epochs
                            ,verbose=1,validation_data=valid_generator(),callbacks=callbacks
                            ,validation_steps=len(ids_valid_split)//batch_size)
