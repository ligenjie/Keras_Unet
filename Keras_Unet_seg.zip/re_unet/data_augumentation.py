# -*-coding:utf-8-*-
"""
@Time:      2020-05-28  16:45
@Author:    Genjie
@IDE:       PyCharm
"""
import cv2
from scipy.ndimage.filters import gaussian_filter
from scipy.ndimage.interpolation import map_coordinates
import numpy as np
import os
import matplotlib.pyplot as plt

def randomHueSaturationVaule(image,hue_shift_limit=(-180,180),
                             sat_shift_limit=(-255,255),
                             val_shifit_limit = (-255,255),u=0.5):
    if np.random.random()<u:
        image = cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
        h,s,v = cv2.split(image)
        hue_shift = np.random.uniform(hue_shift_limit[0],hue_shift_limit[1])
        h = cv2.add(h,hue_shift)
        sat_shift = np.random.uniform(sat_shift_limit[0],sat_shift_limit[1])
        s = cv2.add(s,sat_shift)
        val_shifit = np.random.uniform(val_shifit_limit[0],val_shifit_limit[1])
        v = cv2.add(v,val_shifit)
        image = cv2.merge(h,s,v)
        image = cv2.cvtColor(image,cv2.COLOR_HSV2BGR)
    return image

def rot90_n(image,all_masks):
    k = np.random.randint(1,3)
    #可以这样认为，ascontiguousarray函数将一个内存不连续存储的数组转换为内存连续存储的数组，使得运行速度更快。
    transformed_image = np.ascontiguousarray(np.rot90(image,k))
    transformed_masks = []
    for _,mask in enumerate(all_masks):
        transformed_mask = np.ascontiguousarray(np.rot90(mask,k))
        transformed_masks.append(transformed_mask)
    return transformed_image,transformed_masks

def randomShiftScaleRotate(image,all_masks
                           ,shift_limit = (-0.0625,0.0625)
                           ,scale_limit = (-0.1,0.1)
                           ,rotate_limit=(-45,45)
                           ,aspect_limit = (0,0)
                           ,border_mode = cv2.BORDER_CONSTANT,u=1.0):
    if np.random.random()<u:
        height,width,channel = image.shape

        angle = np.random.uniform(rotate_limit[0],rotate_limit[1])
        scale = np.random.uniform(1+scale_limit[0],1+scale_limit[1])
        aspect = np.random.uniform(1+aspect_limit[0],1+aspect_limit[1])

        sx = scale*aspect/(aspect**0.5)
        sy = scale/(aspect**0.5)

        dx = round(np.random.uniform(shift_limit[0],shift_limit[1])*width)
        dy = round(np.random.uniform(shift_limit[0],shift_limit[1])*height)

        cc = np.math.cos(angle/180*np.math.pi)*sx
        ss = np.math.sin(angle/180*np.math.pi)*sy
        rotate_matrix = np.asarray([[cc,-ss],[ss,cc]])

        box0 = np.array([[0,0],[width,0],[width,height],[0,height],])
        box1 = box0-np.array([width/2,height/2])
        box1 = np.dot(box1,rotate_matrix.T)+np.array([width/2+dx,height/2+dy])

        box0 = box0.astype(np.float32)
        box1 = box1.astype(np.float32)
        mat = cv2.getPerspectiveTransform(box0,box1)
        transformed_image = cv2.warpPerspective(image,mat,(width,height),flags=cv2.INTER_LINEAR
                                                ,borderMode=border_mode,
                                                borderValue=(
                                                    0,0,0,
                                                ))
        transformed_masks = []
        for _,mask in enumerate(all_masks):
            transformed_mask = cv2.warpPerspective(mask,mat,(width,height),flags=cv2.INTER_LINEAR,
                                                   borderMode=border_mode,
                                                   borderValue=(
                                                       0,0,0,
                                                   ))
            transformed_masks.append(transformed_mask)
        return transformed_image,transformed_masks
    return image,all_masks

def randomHorizontalFlip(image,all_masks,u=0.5):
    if np.random.random()<u:
        transformed_image = cv2.flip(image,1)
        transformed_masks = []
        for _,mask in enumerate(all_masks):
            mask = cv2.flip(mask,1)
            transformed_masks.append(mask)
        return transformed_image,transformed_masks
    return image,all_masks

def randomElasticTransformation(image,all_masks,alpha=1500,sigma=50,rng=np.random.RandomState(42)
                                ,interpolation_order=1,u=0.5):
    if np.random.random()<u:
        height,width,channel = image.shape
        dx = rng.uniform(-1,1,[height,width])*alpha
        dy = rng.uniform(-1,1,[height,width])*alpha

        sdx = gaussian_filter(dx,sigma=sigma,mode = 'reflect')
        sdy = gaussian_filter(dy,sigma=sigma,mode = 'reflect')

        x,y = np.meshgrid(np.arange(width),np.arange(height))
        distorted_indices = (y+sdy).reshape(-1,1),(x+sdx).reshape(-1,1)
        all_channels = []
        for channel_id in range(channel):
            all_channels.append(map_coordinates(image[...,channel_id],distorted_indices,mode='reflect'
                                                ,order = interpolation_order).reshape(height,width,1))
            transformed_image = np.concatenate(all_channels,axis=-1)
            transformed_masks = []

            for _,mask in enumerate(all_masks):
                transformed_mask = map_coordinates(mask,distorted_indices,mode='reflect'
                                                   ,order=interpolation_order).reshape(height,width)
                transformed_masks.append(transformed_mask)
                return transformed_image,transformed_masks
            return  image,all_masks

